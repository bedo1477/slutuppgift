require('dotenv').config();
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const app = express();

// Säkerhetsinställningar
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: ["'self'", "'unsafe-inline'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'", "http://localhost:3000", "http://10.1.1.222:3000"]
        }
    }
}));

// CORS-inställningar
app.use(cors({
    origin: function(origin, callback) {
        const allowedOrigins = [
            'http://localhost:3000',
            'http://127.0.0.1:3000',
            'http://localhost:5500',
            'http://127.0.0.1:5500',
            'http://localhost:5501',
            'http://127.0.0.1:5501',
            'http://localhost:5502',
            'http://127.0.0.1:5502',
            'http://localhost:5503',
            'http://127.0.0.1:5503',
            'http://10.1.1.222:3000'
        ];
        
        if (!origin || allowedOrigins.indexOf(origin) !== -1) {
            callback(null, true);
        } else {
            callback(new Error('CORS not allowed'));
        }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Accept', 'Origin'],
    exposedHeaders: ['Set-Cookie']
}));

// Hantera preflight-förfrågningar
app.options('*', cors());

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minuter
    max: 100 // max 100 förfrågningar per fönster
});
app.use(limiter);

// Middleware för att hantera JSON och cookies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Logga alla inkommande förfrågningar
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
});

// Databasanslutning
const db = mysql.createConnection({
    host: process.env.DB_HOST || '10.1.1.222',
    user: process.env.DB_USER || 'bedkio',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'bedkio'
});

// Anslut till databasen
db.connect((err) => {
    if (err) {
        console.error('Fel vid anslutning till databasen:', err);
        process.exit(1);
    }
    console.log('Ansluten till databasen');
});

// Funktion för att logga till fil
const logToFile = (message) => {
    const logDir = path.join(__dirname, 'logs');
    const logFile = path.join(logDir, 'server.log');
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] ${message}\n`;

    if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
    }

    fs.appendFile(logFile, logMessage, (err) => {
        if (err) {
            console.error('Fel vid loggning till fil:', err);
        }
    });
};

// Middleware för att verifiera JWT-token
const authenticateToken = (req, res, next) => {
    const token = req.cookies.token || req.headers['authorization']?.split(' ')[1];

    if (!token) {
        console.error('Ingen token tillhandahållen');
        return res.status(401).json({ error: 'Ingen token tillhandahållen' });
    }

    jwt.verify(token, process.env.JWT_SECRET || 'din_hemliga_nyckel', (err, user) => {
        if (err) {
            console.error('Token verifieringsfel:', err);
            if (err.name === 'TokenExpiredError') {
                // Rensa cookie om token har gått ut
                res.clearCookie('token', {
                    httpOnly: true,
                    secure: process.env.NODE_ENV === 'production',
                    sameSite: 'strict'
                });
                return res.status(401).json({ 
                    error: 'Din session har gått ut',
                    details: 'Logga in igen för att fortsätta'
                });
            }
            return res.status(403).json({ error: 'Ogiltig token' });
        }

        const now = Math.floor(Date.now() / 1000);
        if (user.exp && user.exp < now) {
            // Rensa cookie om token har gått ut
            res.clearCookie('token', {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                sameSite: 'strict'
            });
            return res.status(401).json({ 
                error: 'Din session har gått ut',
                details: 'Logga in igen för att fortsätta'
            });
        }

        if (!user.userId || !user.username) {
            return res.status(403).json({ error: 'Ogiltig användarinformation' });
        }

        console.log('Token verifierad för användare:', user.username);
        req.user = user;
        next();
    });
};

// Test-endpoint
app.get('/api/test', (req, res) => {
    console.log('Test-endpoint nådd från:', req.headers.origin);
    res.json({ 
        message: 'Server är igång!',
        timestamp: new Date().toISOString(),
        status: 'ok'
    });
});

// Test-endpoint för att kontrollera tabellstrukturen
app.get('/api/test/tables', (req, res) => {
    db.query('SHOW TABLES', (err, results) => {
        if (err) {
            console.error('Fel vid hämtning av tabeller:', err);
            return res.status(500).json({ error: 'Kunde inte hämta tabeller' });
        }
        console.log('Tabeller i databasen:', results);
        res.json(results);
    });
});

// Visa kolumner i Users-tabellen
app.get('/api/test/columns', (req, res) => {
    db.query('SHOW COLUMNS FROM Users', (err, results) => {
        if (err) {
            console.error('Fel vid hämtning av kolumner:', err);
            return res.status(500).json({ error: 'Kunde inte hämta kolumner' });
        }
        console.log('Kolumner i Users-tabellen:', results);
        res.json(results);
    });
});

// Lägg till created_at-kolumn om den inte finns
app.get('/api/test/add-column', (req, res) => {
    db.query(
        'ALTER TABLE Users ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
        (err, results) => {
            if (err) {
                console.error('Fel vid tillägg av kolumn:', err);
                return res.status(500).json({ error: 'Kunde inte lägga till kolumn' });
            }
            console.log('Kolumn created_at tillagd eller redan existerande');
            res.json({ message: 'Kolumn created_at tillagd eller redan existerande' });
        }
    );
});

// Registreringsendpoint
app.post('/api/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;
        console.log('Registreringsförsök:', { username, email });

        if (!username || !email || !password) {
            return res.status(400).json({ error: 'Alla fält måste fyllas i' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        
        db.query(
            'INSERT INTO Users (username, email, password_hash, created_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)',
            [username, email, hashedPassword],
            (err, result) => {
                if (err) {
                    console.error('Databasfel vid registrering:', err);
                    if (err.code === 'ER_DUP_ENTRY') {
                        return res.status(400).json({ error: 'Användarnamn eller e-post finns redan' });
                    }
                    return res.status(500).json({ error: 'Databasfel' });
                }
                console.log('Användare skapad:', username);
                res.status(201).json({ message: 'Användare skapad' });
            }
        );
    } catch (error) {
        console.error('Serverfel vid registrering:', error);
        res.status(500).json({ error: 'Serverfel' });
    }
});

// Säker SQL-fråga funktion
const safeQuery = async (query, params) => {
    return new Promise((resolve, reject) => {
        db.query(query, params, (err, results) => {
            if (err) {
                console.error('Databasfel:', err);
                reject(err);
            } else {
                resolve(results);
            }
        });
    });
};

// Konfigurera multer för bilduppladdningar
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
        cb(null, uniqueSuffix + path.extname(file.originalname))
    }
});

const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 5 * 1024 * 1024 // 5MB max
    },
    fileFilter: function (req, file, cb) {
        if (!file.originalname.match(/\.(jpg|jpeg|png|gif)$/)) {
            return cb(new Error('Endast bildfiler är tillåtna!'), false);
        }
        cb(null, true);
    }
});

// Inloggningsendpoint
app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        console.log('Inloggningsförsök för användare:', username);

        if (!username || !password) {
            console.error('Saknad data:', { username: !!username, password: !!password });
            return res.status(400).json({ error: 'Användarnamn och lösenord krävs' });
        }

        if (db.state === 'disconnected') {
            console.error('Databasanslutning saknas');
            return res.status(500).json({ error: 'Databasanslutning saknas' });
        }

        const users = await new Promise((resolve, reject) => {
            db.query(
                'SELECT * FROM Users WHERE username = ?',
                [username],
                (err, results) => {
                    if (err) reject(err);
                    else resolve(results);
                }
            );
        });

        if (users.length === 0) {
            console.error('Användare hittades inte:', username);
            return res.status(401).json({ 
                error: 'Felaktigt användarnamn eller lösenord',
                details: 'Användarnamnet finns inte i systemet'
            });
        }

        const user = users[0];
        console.log('Användare hittad:', user.username);

        const validPassword = await bcrypt.compare(password, user.password_hash);
        console.log('Lösenordsjämförelse:', validPassword ? 'Korrekt' : 'Felaktigt');

        if (!validPassword) {
            console.error('Felaktigt lösenord för användare:', username);
            return res.status(401).json({ 
                error: 'Felaktigt användarnamn eller lösenord',
                details: 'Lösenordet är felaktigt'
            });
        }

        const token = jwt.sign(
            { 
                userId: user.user_id, 
                username: user.username,
                exp: Math.floor(Date.now() / 1000) + (20 * 60) // 20 minuter
            },
            process.env.JWT_SECRET || 'din_hemliga_nyckel',
            { algorithm: 'HS256' }
        );

        res.cookie('token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 20 * 60 * 1000 // 20 minuter
        });

        console.log('Inloggning lyckades för användare:', username);
        res.json({
            message: 'Inloggning lyckades',
            token: token,
            user: {
                id: user.user_id,
                username: user.username
            }
        });
    } catch (error) {
        console.error('Inloggningsfel:', error);
        res.status(500).json({ 
            error: 'Ett fel uppstod vid inloggning',
            details: error.message
        });
    }
});

// Utloggningsendpoint
app.post('/api/logout', (req, res) => {
    res.clearCookie('token', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict'
    });
    res.json({ message: 'Utloggad' });
});

// Exempel på en skyddad route som kräver token
app.get('/api/protected', authenticateToken, (req, res) => {
    res.json({ message: 'Detta är skyddat innehåll', user: req.user });
});

// Logg-endpoints
app.get('/api/logs', authenticateToken, (req, res) => {
    console.log('Försöker hämta loggar för användare:', req.user.userId);
    
    db.query(
        'SELECT * FROM Logs WHERE user_id = ? ORDER BY created_at DESC',
        [req.user.userId],
        (err, results) => {
            if (err) {
                console.error('Fel vid hämtning av loggar:', err);
                return res.status(500).json({ 
                    error: 'Kunde inte hämta loggar',
                    details: err.message 
                });
            }
            console.log('Loggar hämtade:', results.length);
            res.json(results);
        }
    );
});

app.post('/api/logs', authenticateToken, (req, res) => {
    const { title, content } = req.body;
    console.log('Försöker skapa logg för användare:', req.user.userId);
    
    if (!title || !content) {
        console.error('Saknad data:', { title, content });
        return res.status(400).json({ error: 'Titel och innehåll krävs' });
    }

    db.query(
        'INSERT INTO Logs (user_id, title, content) VALUES (?, ?, ?)',
        [req.user.userId, title, content],
        (err, result) => {
            if (err) {
                console.error('Fel vid skapande av logg:', err);
                return res.status(500).json({ 
                    error: 'Kunde inte skapa logg',
                    details: err.message 
                });
            }
            console.log('Logg skapad:', result.insertId);
            res.status(201).json({ 
                log_id: result.insertId,
                title,
                content,
                created_at: new Date()
            });
        }
    );
});

app.delete('/api/logs/:id', authenticateToken, (req, res) => {
    const logId = req.params.id;
    console.log('Försöker ta bort logg:', logId, 'för användare:', req.user.userId);

    db.query(
        'DELETE FROM Logs WHERE log_id = ? AND user_id = ?',
        [logId, req.user.userId],
        (err, result) => {
            if (err) {
                console.error('Fel vid borttagning av logg:', err);
                return res.status(500).json({ 
                    error: 'Kunde inte ta bort logg',
                    details: err.message 
                });
            }
            if (result.affectedRows === 0) {
                console.log('Logg hittades inte:', logId);
                return res.status(404).json({ error: 'Logg hittades inte' });
            }
            console.log('Logg borttagen:', logId);
            res.json({ message: 'Logg borttagen' });
        }
    );
});

// Hämta alla inlägg för en användare
app.get('/api/posts', authenticateToken, (req, res) => {
    console.log('Försöker hämta inlägg för användare:', req.user.userId);
    console.log('Authorization header:', req.headers.authorization);
    
    if (!req.user || !req.user.userId) {
        console.error('Ingen användarinformation tillgänglig');
        return res.status(401).json({ error: 'Ingen användarinformation tillgänglig' });
    }

    if (db.state === 'disconnected') {
        console.error('Databasanslutning saknas');
        return res.status(500).json({ error: 'Databasanslutning saknas' });
    }
    
    // Kontrollera att användaren finns
    db.query(
        'SELECT user_id FROM Users WHERE user_id = ?',
        [req.user.userId],
        (err, results) => {
            if (err) {
                console.error('Fel vid användarkontroll:', err);
                return res.status(500).json({ error: 'Databasfel vid användarkontroll' });
            }

            if (results.length === 0) {
                console.error('Användare hittades inte:', req.user.userId);
                return res.status(404).json({ error: 'Användare hittades inte' });
            }

            // Hämta inlägg
            db.query(
                'SELECT * FROM Videos WHERE user_id = ? ORDER BY upload_date DESC',
                [req.user.userId],
                (err, results) => {
                    if (err) {
                        console.error('Fel vid hämtning av inlägg:', err);
                        return res.status(500).json({ 
                            error: 'Kunde inte hämta inlägg',
                            details: err.message 
                        });
                    }
                    console.log('Inlägg hämtade:', results.length);
                    res.json(results);
                }
            );
        }
    );
});

// Skapa nytt inlägg
app.post('/api/posts', authenticateToken, upload.single('image'), async (req, res) => {
    try {
        const { title, description, is_log } = req.body;
        console.log('Försöker skapa inlägg för användare:', req.user.userId);
        console.log('Inkommande data:', { title, description, is_log });
        
        if (!title) {
            console.error('Saknad data:', { title });
            return res.status(400).json({ error: 'Titel krävs' });
        }

        let video_url = null;
        if (req.file) {
            video_url = `/uploads/${req.file.filename}`;
        }

        // Konvertera is_log till boolean
        const isLog = is_log === 'true' ? 1 : 0;

        // Kontrollera databasanslutning
        if (db.state === 'disconnected') {
            console.error('Databasanslutning saknas');
            return res.status(500).json({ error: 'Databasanslutning saknas' });
        }

        // Validera att användaren finns
        db.query(
            'SELECT user_id FROM Users WHERE user_id = ?',
            [req.user.userId],
            (err, results) => {
                if (err) {
                    console.error('Fel vid användarkontroll:', err);
                    return res.status(500).json({ 
                        error: 'Databasfel vid användarkontroll',
                        details: err.message 
                    });
                }

                if (results.length === 0) {
                    console.error('Användare hittades inte:', req.user.userId);
                    return res.status(404).json({ error: 'Användare hittades inte' });
                }

                // Skapa inlägget
                db.query(
                    'INSERT INTO Videos (user_id, title, description, video_url, is_log) VALUES (?, ?, ?, ?, ?)',
                    [req.user.userId, title, description, video_url, isLog],
                    (err, result) => {
                        if (err) {
                            console.error('Fel vid skapande av inlägg:', err);
                            return res.status(500).json({ 
                                error: 'Kunde inte skapa inlägg',
                                details: err.message 
                            });
                        }
                        console.log('Inlägg skapat:', result.insertId);
                        res.status(201).json({ 
                            video_id: result.insertId,
                            title,
                            description,
                            video_url,
                            is_log: isLog,
                            upload_date: new Date()
                        });
                    }
                );
            }
        );
    } catch (error) {
        console.error('Oväntat fel vid skapande av inlägg:', error);
        res.status(500).json({ 
            error: 'Ett oväntat fel uppstod',
            details: error.message 
        });
    }
});

app.delete('/api/posts/:id', authenticateToken, (req, res) => {
    const postId = req.params.id;
    console.log('Försöker ta bort inlägg:', postId, 'för användare:', req.user.userId);

    db.query(
        'DELETE FROM Videos WHERE video_id = ? AND user_id = ?',
        [postId, req.user.userId],
        (err, result) => {
            if (err) {
                console.error('Fel vid borttagning av inlägg:', err);
                return res.status(500).json({ 
                    error: 'Kunde inte ta bort inlägg',
                    details: err.message 
                });
            }
            if (result.affectedRows === 0) {
                console.log('Inlägg hittades inte:', postId);
                return res.status(404).json({ error: 'Inlägg hittades inte' });
            }
            console.log('Inlägg borttaget:', postId);
            res.json({ message: 'Inlägg borttaget' });
        }
    );
});

// Hämta alla inlägg (publikt)
app.get('/api/posts/all', (req, res) => {
    console.log('Försöker hämta alla inlägg');
    
    db.query(
        `SELECT v.*, u.username 
         FROM Videos v 
         JOIN Users u ON v.user_id = u.user_id 
         ORDER BY v.upload_date DESC`,
        (err, results) => {
            if (err) {
                console.error('Fel vid hämtning av alla inlägg:', err);
                return res.status(500).json({ 
                    error: 'Kunde inte hämta inlägg',
                    details: err.message 
                });
            }
            console.log('Alla inlägg hämtade:', results.length);
            res.json(results);
        }
    );
});

// Hämta kommentarer för ett inlägg
app.get('/api/comments/:videoId', (req, res) => {
    const videoId = req.params.videoId;
    console.log('Försöker hämta kommentarer för inlägg:', videoId);
    
    // Först kontrollera att inlägget finns
    db.query(
        'SELECT video_id FROM Videos WHERE video_id = ?',
        [videoId],
        (err, results) => {
            if (err) {
                console.error('Fel vid kontroll av inlägg:', err);
                return res.status(500).json({ 
                    error: 'Databasfel vid kontroll av inlägg',
                    details: err.message,
                    sql: 'SELECT video_id FROM Videos WHERE video_id = ?'
                });
            }

            if (results.length === 0) {
                console.log('Inlägg hittades inte:', videoId);
                return res.status(404).json({ error: 'Inlägg hittades inte' });
            }

            // Hämta kommentarer
            const query = `
                SELECT c.*, u.username 
                FROM Comments c 
                JOIN Users u ON c.user_id = u.user_id 
                WHERE c.video_id = ? 
                ORDER BY c.comment_date DESC
            `;
            
            console.log('Kör SQL-fråga:', query, 'med videoId:', videoId);
            
            db.query(query, [videoId], (err, comments) => {
                if (err) {
                    console.error('Fel vid hämtning av kommentarer:', err);
                    return res.status(500).json({ 
                        error: 'Kunde inte hämta kommentarer',
                        details: err.message,
                        sql: query
                    });
                }
                console.log('Kommentarer hämtade:', comments.length);
                res.json(comments);
            });
        }
    );
});

// Lägg till kommentar
app.post('/api/comments', authenticateToken, (req, res) => {
    try {
        const { video_id, comment_text } = req.body;
        console.log('Försöker lägga till kommentar:', { video_id, comment_text });
        
        if (!video_id || !comment_text) {
            console.error('Saknad data:', { video_id, comment_text });
            return res.status(400).json({ error: 'Video ID och kommentar krävs' });
        }

        // Först kontrollera att inlägget finns
        db.query(
            'SELECT video_id FROM Videos WHERE video_id = ?',
            [video_id],
            (err, results) => {
                if (err) {
                    console.error('Fel vid kontroll av inlägg:', err);
                    return res.status(500).json({ 
                        error: 'Databasfel vid kontroll av inlägg',
                        details: err.message 
                    });
                }

                if (results.length === 0) {
                    console.log('Inlägg hittades inte:', video_id);
                    return res.status(404).json({ error: 'Inlägg hittades inte' });
                }

                // Lägg till kommentaren
                db.query(
                    'INSERT INTO Comments (user_id, video_id, comment_text) VALUES (?, ?, ?)',
                    [req.user.userId, video_id, comment_text],
                    (err, result) => {
                        if (err) {
                            console.error('Fel vid tillägg av kommentar:', err);
                            return res.status(500).json({ 
                                error: 'Kunde inte lägga till kommentar',
                                details: err.message 
                            });
                        }
                        console.log('Kommentar tillagd:', result.insertId);
                        
                        // Hämta den nya kommentaren med användarinformation
                        db.query(
                            `SELECT c.*, u.username 
                             FROM Comments c 
                             JOIN Users u ON c.user_id = u.user_id 
                             WHERE c.comment_id = ?`,
                            [result.insertId],
                            (err, comment) => {
                                if (err) {
                                    console.error('Fel vid hämtning av ny kommentar:', err);
                                    return res.status(500).json({ 
                                        error: 'Kunde inte hämta ny kommentar',
                                        details: err.message 
                                    });
                                }
                                res.status(201).json(comment[0]);
                            }
                        );
                    }
                );
            }
        );
    } catch (error) {
        console.error('Oväntat fel vid tillägg av kommentar:', error);
        res.status(500).json({ 
            error: 'Ett oväntat fel uppstod',
            details: error.message 
        });
    }
});

// Lägg till statisk filhantering för uploads-mappen
app.use('/uploads', express.static('uploads'));

app.get('/api/test/add-column', (req, res) => {
    db.query(
        'ALTER TABLE Users ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
        (err, results) => {
            if (err) {
                console.error('Fel vid tillägg av kolumn:', err);
                return res.status(500).json({ error: 'Kunde inte lägga till kolumn' });
            }
            console.log('Kolumn created_at tillagd eller redan existerande');
            res.json({ message: 'Kolumn created_at tillagd eller redan existerande' });
        }
    );
});
// Hämta användarinformation
app.get('/api/user', authenticateToken, (req, res) => {
    console.log('Försöker hämta användarinformation för:', req.user.userId);
    
    db.query(
        'SELECT username, email FROM Users WHERE user_id = ?',
        [req.user.userId],
        (err, results) => {
            if (err) {
                console.error('Fel vid hämtning av användarinformation:', err);
                return res.status(500).json({ 
                    error: 'Kunde inte hämta användarinformation',
                    details: err.message 
                });
            }

            if (results.length === 0) {
                console.log('Användare hittades inte:', req.user.userId);
                return res.status(404).json({ error: 'Användare hittades inte' });
            }

            const user = results[0];
            console.log('Användarinformation hämtad:', user.username);
            res.json(user);
        }
    );
});

// Radera användare
app.delete('/api/user', authenticateToken, (req, res) => {
    console.log('Försöker radera användare:', req.user.userId);
    
    db.query(
        'DELETE FROM Users WHERE user_id = ?',
        [req.user.userId],
        (err, result) => {
            if (err) {
                console.error('Fel vid radering av användare:', err);
                return res.status(500).json({ 
                    error: 'Kunde inte radera användare',
                    details: err.message 
                });
            }

            if (result.affectedRows === 0) {
                console.log('Användare hittades inte för radering:', req.user.userId);
                return res.status(404).json({ error: 'Användare hittades inte' });
            }

            console.log('Användare raderad:', req.user.userId);
            res.json({ message: 'Användare raderad' });
        }
    );
});

// Hantera 404-fel
app.use((req, res, next) => {
    console.error('404 - Sökväg hittades inte:', req.method, req.url);
    res.status(404).json({ 
        error: 'Sökväg hittades inte',
        path: req.url,
        method: req.method
    });
});

// Felhanteringsmiddleware
app.use((err, req, res, next) => {
    console.error('Serverfel:', err);
    res.status(500).json({ 
        error: 'Ett serverfel uppstod',
        message: err.message,
        timestamp: new Date().toISOString()
    });
});

const PORT = process.env.PORT || 3000;
console.log('Startar server...');
console.log('Port:', PORT);
console.log('Databasinställningar:', {
    host: process.env.DB_HOST || '10.1.1.222',
    user: process.env.DB_USER || 'bedkio',
    database: process.env.DB_NAME || 'bedkio'
});

// Öka max antal lyssnare
const server = app.listen(PORT, '0.0.0.0', () => {
    logToFile(`Server startad på port ${PORT}`);
    console.log(`Server kör på http://localhost:${PORT}`);
    console.log('Testa servern genom att besöka: http://localhost:3000/api/test');
});

// Sätt max antal lyssnare
server.setMaxListeners(20);

// Hantera serverfel
server.on('error', (error) => {
    console.error('Serverfel:', error);
    if (error.code === 'EADDRINUSE') {
        console.error(`Port ${PORT} är redan i användning. Försök att stoppa andra processer som använder denna port.`);
    }
    process.exit(1);
});

// Städa upp databasanslutningen när servern stängs
process.on('SIGINT', () => {
    console.log('Stänger databasanslutningen...');
    db.end((err) => {
        if (err) {
            console.error('Fel vid stängning av databasanslutning:', err);
        } else {
            console.log('Databasanslutning stängd');
        }
        process.exit(0);
    });
});

// Städa upp lyssnare när servern stängs
server.on('close', () => {
    console.log('Server stängd, städar upp lyssnare...');
    server.removeAllListeners();
}); 